package com.example.fragment.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.fragment.R;
import com.example.fragment.fragment.About;
import com.example.fragment.fragment.Dashboard;
import com.example.fragment.fragment.Help;

public class MainActivity extends FragmentActivity implements View.OnClickListener {
    Button btnDashboard, btnAbout, btnHelp, btnLogout;

    Dashboard fragmentDashboard;
    About fragmentAbout;
    Help fragmentHelp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDashboard = findViewById(R.id.btn_dashboard);
        btnAbout = findViewById(R.id.btn_about);
        btnHelp = findViewById(R.id.btn_help);
        btnLogout = findViewById(R.id.btn_logout);

        btnDashboard.setOnClickListener(this);
        btnAbout.setOnClickListener(this);
        btnHelp.setOnClickListener(this);
        btnLogout.setOnClickListener(this);
    }

    void menuDashboard() {
        fragmentDashboard = new Dashboard();
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragmentDashboard);
        ft.commit();
    }

    void menuAbout() {
        fragmentAbout = new About();
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragmentAbout);
        ft.commit();
    }

    void menuHelp() {
        fragmentHelp = new Help();
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragmentHelp);
    }

    void menuLogout() {
        finish();
    }

    @Override
    public void onClick(View v) {
        if (v == btnDashboard) {
            menuDashboard();
        }
        if (v == btnAbout) {
            menuAbout();
        }
        if (v == btnHelp) {
            menuHelp();
        }
        if (v == btnLogout) {
            menuLogout();
        }
    }
}